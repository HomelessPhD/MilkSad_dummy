/*  Copyright (c) 2015 Ryan Castellucci, All Rights Reserved */
#ifndef __BRAINFLAYER_WARPWALLET_H_
#define __BRAINFLAYER_WARPWALLET_H_

int warpwallet(unsigned char *, size_t, unsigned char *, size_t, unsigned char *);

/* vim: set ts=2 sw=2 et ai si: */
#endif /* __BRAINFLAYER_WARPWALLET_H_ */
